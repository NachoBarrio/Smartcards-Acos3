card = new Card();
atr = card.reset(Card.RESET_COLD);
//print(atr);
print("");

print("          FICHERO USER FILE MANAGEMENT FF04");
resp = card.plainApdu(new ByteString("80 A4 00 00 02 FF 04", HEX));
print("");

print("Escribir en fichero 8DC1");
resp = card.plainApdu(new ByteString("80 D0 00 00 96 38 44 43 31 20 49 67 6e 61 63 69 6f 20 42 61 72 72 69 6f 20 53 61 6e 74 6f 73 20 4d 41 53 54 45 52 20 44 45 20 53 49 53 54 45 4d 41 53 20 41 70 6c 69 63 61 63 69 6f 6e 65 73 20 70 61 72 61 20 53 6d 61 72 74 20 43 61 72 64 73 20 32 30 31 37 20 32 30 31 38 20 38 44 43 31 20 45 6e 20 75 6e 20 6c 75 67 61 72 20 64 65 20 6c 61 20 6d 61 6e 63 68 61 20 64 65 20 63 75 79 6f 20 6e 6f 6d 62 72 65 20 6e 6f 20 71 75 69 65 72 6f 20 61 63 6f 72 64 61 72 6d 65",HEX));
print("Código SW: " + card.SW.toString(16));